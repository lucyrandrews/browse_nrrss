library(shiny)

fluidPage(leafletOutput('mymap'))